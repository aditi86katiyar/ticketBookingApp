package com.sapient.vo;

public enum PAYMENT_STATUS {
	PAID,
	UNPAID

}
