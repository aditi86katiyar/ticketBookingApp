package com.sapient.vo;

public class MovieLanguages {
	Long movie_language_id;
	
	String Language;
	

}
