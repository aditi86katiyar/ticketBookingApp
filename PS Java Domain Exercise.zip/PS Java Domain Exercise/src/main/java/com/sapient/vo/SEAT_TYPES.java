package com.sapient.vo;

public enum SEAT_TYPES {
	SILVER,
	GOLD,
	PLATINUM

}
