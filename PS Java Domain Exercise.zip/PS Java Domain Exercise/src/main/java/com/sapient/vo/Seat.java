package com.sapient.vo;

public class Seat {
	
	    private Integer fromSeat;
	    private Integer toSeat;
	    private String seatType;
	    private double price;
		public String getSeatType() {
			return seatType;
		}
		public void setSeatType(String seatType) {
			this.seatType = seatType;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		public Integer getFromSeat() {
			return fromSeat;
		}
		public void setFromSeat(Integer fromSeat) {
			this.fromSeat = fromSeat;
		}
		public Integer getToSeat() {
			return toSeat;
		}
		public void setToSeat(Integer toSeat) {
			this.toSeat = toSeat;
		}
		
		
		
	   
		
  	}

