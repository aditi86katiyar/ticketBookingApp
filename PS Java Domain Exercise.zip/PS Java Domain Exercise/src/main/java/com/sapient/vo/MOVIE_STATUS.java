package com.sapient.vo;

public enum MOVIE_STATUS {
	
	MOVIE_AVAILABLE,
	MOVIE_NOT_AVAILABLE

}
