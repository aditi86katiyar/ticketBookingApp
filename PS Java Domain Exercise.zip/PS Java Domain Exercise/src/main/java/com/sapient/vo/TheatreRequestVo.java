package com.sapient.vo;

import java.util.Date;

public class TheatreRequestVo {
	
	String movie;
	
	Date showTime;
	
	
	String city;


	public String getMovie() {
		return movie;
	}


	public void setMovie(String movie) {
		this.movie = movie;
	}


	public Date getShowTime() {
		return showTime;
	}


	public void setShowTime(Date showTime) {
		this.showTime = showTime;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}
	
	
		
}
