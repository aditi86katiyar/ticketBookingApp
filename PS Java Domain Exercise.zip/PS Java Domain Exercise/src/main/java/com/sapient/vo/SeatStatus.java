package com.sapient.vo;

public enum SeatStatus {

}
